define(
({
		previousMessage: "Choix précédents",
		nextMessage: "Plus de choix"
})
);
