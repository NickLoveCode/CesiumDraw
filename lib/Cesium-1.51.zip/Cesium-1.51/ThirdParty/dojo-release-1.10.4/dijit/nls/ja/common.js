define(
({
	buttonOk: "OK",
	buttonCancel: "キャンセル",
	buttonSave: "保存",
	itemClose: "閉じる"
})
);
