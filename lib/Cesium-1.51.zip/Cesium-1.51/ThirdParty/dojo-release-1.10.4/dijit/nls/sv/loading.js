define(
({
	loadingState: "Läser in...",
	errorState: "Det har inträffat ett fel."
})
);
