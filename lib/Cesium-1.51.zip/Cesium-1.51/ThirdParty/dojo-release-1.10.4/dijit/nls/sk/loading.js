define(
({
	loadingState: "Zavádza sa...",
	errorState: "Ľutujeme, ale vyskytla sa chyba"
})
);
