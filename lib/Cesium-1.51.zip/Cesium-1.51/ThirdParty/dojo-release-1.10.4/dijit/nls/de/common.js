define(
({
	buttonOk: "OK",
	buttonCancel: "Abbrechen",
	buttonSave: "Speichern",
	itemClose: "Schließen"
})
);
